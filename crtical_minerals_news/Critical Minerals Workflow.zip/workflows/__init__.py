"""
Workflows module for Critical Minerals News Discovery.
"""

from .enhanced_workflow import enhanced_workflow

__all__ = ["enhanced_workflow"]
